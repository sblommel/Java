

public class FirstJava {
    public static void main (String[] args){

        String name = "Samira";
        int age = 45;
        String hometown = "Orlando, FL";

        System.out.println("hello world!");
        System.out.printf("My name is %s, I am %s years old, and my hometown is %s", name, age, hometown);
    }
}
